<template>
    <div>
        <h2 class="text-center h2">訂購須知</h2>
        <p>
        <span class="h5 pb-2 text-primary"><strong>退換貨說明</strong></span>
        <br>
        <br>
        會員所購買的商品均享有到貨十天的猶豫期（含例假日）。退回之商品必須於猶豫期內寄回。
        <br>
        <br>
        辦理退換貨時，商品必須是全新狀態與完整包裝<span class="text-danger"><strong>
        (請注意保持商品本體、配件、贈品、保證書、原廠包裝及所有附隨文件或資料的完整性，切勿缺漏任何配件或損毀原廠外盒)
        </strong></span>
        。退回商品無法回復原狀者，恐將影響退貨權益或需負擔部分費用。
        <br>
        <br>
        訂購本商品前請務必詳閱商品退換貨原則。
        </p>
    </div>
</template>
