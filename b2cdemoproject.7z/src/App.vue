<template>
  <router-view/>
</template>

<style lang="scss">
@import "./assets/all";
</style>
<script>
// 使bootstrap的效果能正常運作
import 'bootstrap/dist/js/bootstrap.bundle';

export default {

};
</script>
